package com.bitc.securityboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityBoardApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityBoardApplication.class, args);
	}

}
