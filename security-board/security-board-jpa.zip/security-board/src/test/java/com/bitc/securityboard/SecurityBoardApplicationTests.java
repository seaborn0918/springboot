package com.bitc.securityboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
